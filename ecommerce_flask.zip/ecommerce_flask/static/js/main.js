/* ShopNova — main.js */

// Auto-dismiss flash messages dopo 4.5s (anche gestito inline in base.html)
document.addEventListener('DOMContentLoaded', () => {

  // Conferma eliminazione elementi via data attribute
  document.querySelectorAll('[data-confirm]').forEach(el => {
    el.addEventListener('click', e => {
      if (!confirm(el.dataset.confirm)) e.preventDefault();
    });
  });

  // Input coupon → uppercase automatico
  const couponInput = document.querySelector('input[name="codice_coupon"]');
  if (couponInput) {
    couponInput.addEventListener('input', () => {
      couponInput.value = couponInput.value.toUpperCase();
    });
  }

  // Input codice coupon admin → uppercase
  const couponAdmin = document.querySelector('input[name="codice"]');
  if (couponAdmin) {
    couponAdmin.addEventListener('input', () => {
      couponAdmin.value = couponAdmin.value.toUpperCase();
    });
  }

  // Tooltip Bootstrap
  document.querySelectorAll('[data-bs-toggle="tooltip"]').forEach(el => {
    new bootstrap.Tooltip(el);
  });

});
