####################################################
#               ShopNova — server.py               #
#                                                  #
#  Comandi per il venv:                            #
#      python -m venv .venv                        #
#      .venv\Scripts\activate   (Windows)          #
#      . .venv/bin/activate     (Linux/Mac)        #
#                                                  #
#  Installazione librerie:                         #
#      pip install flask                           #
#      pip install flask-session                   #
#      pip install mysql-connector-python          #
#      pip install redis                           #
#      pip install python-dotenv                   #
#                                                  #
#  Avvio:                                          #
#      python server.py                            #
#      Password SSL: test  (se usi HTTPS)          #
#                                                  #
#  Requisiti esterni:                              #
#      XAMPP con Apache + MySQL avviato            #
#      Redis avviato (porta 6379)                  #
####################################################

import os
import json
import uuid
import hashlib
import datetime

from flask import (Flask, request, redirect, url_for,
                   render_template, session, flash, abort)
from flask_session import Session
import mysql.connector
from mysql.connector import Error as MySQLError
import redis
from dotenv import load_dotenv

# ─────────────────────────────────────────────────
#  CARICAMENTO .env
# ─────────────────────────────────────────────────
load_dotenv()

# ─────────────────────────────────────────────────
#  CARTELLA IMMAGINI
# ─────────────────────────────────────────────────
IMG_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'static', 'img')
os.makedirs(IMG_FOLDER, exist_ok=True)


def normalizza_immagine(valore):
    """
    Accetta URL esterni (https://...) oppure nomi/percorsi file locali.
    - https://esempio.com/img.jpg  -> invariato
    - scarpe.jpg                   -> /static/img/scarpe.jpg
    - static/img/scarpe.jpg        -> /static/img/scarpe.jpg
    - static\\img\\scarpe.jpg  -> /static/img/scarpe.jpg (percorso Windows)
    - vuoto/None                   -> None
    """
    if not valore:
        return None
    valore = valore.strip()
    if valore.startswith('http://') or valore.startswith('https://'):
        return valore
    # Normalizza i separatori Windows (backslash) e prende solo il nome del file
    valore = valore.replace('\\', '/').replace('\\\\', '/')
    nome = os.path.basename(valore)
    return ('/static/img/' + nome) if nome else None


# ─────────────────────────────────────────────────
#  SETUP FLASK
# ─────────────────────────────────────────────────
app = Flask(__name__)
app.secret_key = os.getenv('SECRET_KEY', 'shopnova_fallback_key')
app.config['SESSION_PERMANENT'] = False
app.config['SESSION_TYPE'] = 'filesystem'
Session(app)

# ─────────────────────────────────────────────────
#  CONNESSIONE MYSQL  (con gestione errori)
# ─────────────────────────────────────────────────
def get_db():
    """Apre (o riapre) la connessione MySQL. Restituisce None se offline."""
    try:
        cnx = mysql.connector.connect(
            host=os.getenv('MYSQL_HOST', '127.0.0.1'),
            user=os.getenv('MYSQL_USER', 'root'),
            password=os.getenv('MYSQL_PASSWORD', ''),
            database=os.getenv('MYSQL_DB', 'ecommerce'),
            connection_timeout=5
        )
        return cnx
    except MySQLError:
        return None

# ─────────────────────────────────────────────────
#  CONNESSIONE REDIS  (con gestione errori)
# ─────────────────────────────────────────────────
def get_redis():
    """Restituisce il client Redis. Restituisce None se offline."""
    try:
        r = redis.Redis(
            host=os.getenv('REDIS_HOST', '127.0.0.1'),
            port=int(os.getenv('REDIS_PORT', 6379)),
            decode_responses=True,
            socket_connect_timeout=3
        )
        r.ping()
        return r
    except Exception:
        return None

# ─────────────────────────────────────────────────
#  HELPER QUERY  (centralizzano accesso al DB)
# ─────────────────────────────────────────────────
def query_fetchall(sql, params=None):
    """Esegue una SELECT e restituisce lista di dict. None se errore."""
    cnx = get_db()
    if not cnx:
        return None
    try:
        with cnx.cursor(dictionary=True) as cur:
            cur.execute(sql, params or ())
            return cur.fetchall()
    except MySQLError:
        return None
    finally:
        cnx.close()


def query_fetchone(sql, params=None):
    """Esegue una SELECT e restituisce il primo dict. None se errore."""
    cnx = get_db()
    if not cnx:
        return None
    try:
        with cnx.cursor(dictionary=True) as cur:
            cur.execute(sql, params or ())
            return cur.fetchone()
    except MySQLError:
        return None
    finally:
        cnx.close()


def query_commit(sql, params=None):
    """Esegue INSERT/UPDATE/DELETE con commit. Restituisce True/False."""
    cnx = get_db()
    if not cnx:
        return False
    try:
        with cnx.cursor() as cur:
            cur.execute(sql, params or ())
        cnx.commit()
        return True
    except MySQLError:
        cnx.rollback()
        return False
    finally:
        cnx.close()


def query_lastrowid(sql, params=None):
    """Esegue INSERT e restituisce l'id generato. None se errore."""
    cnx = get_db()
    if not cnx:
        return None
    try:
        with cnx.cursor() as cur:
            cur.execute(sql, params or ())
            cnx.commit()
            return cur.lastrowid
    except MySQLError:
        cnx.rollback()
        return None
    finally:
        cnx.close()

# ─────────────────────────────────────────────────
#  HASH PASSWORD
# ─────────────────────────────────────────────────
def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()


def get_categoria_path(id_categoria):
    """Risale la gerarchia restituendo il percorso dalla radice."""
    percorso, cat_id, visited = [], id_categoria, set()
    while cat_id and cat_id not in visited:
        visited.add(cat_id)
        cat = query_fetchone('SELECT * FROM categorie WHERE id_categoria=%s', (cat_id,))
        if not cat:
            break
        percorso.insert(0, cat)
        cat_id = cat.get('fk_categoria_c')
    return percorso

# ─────────────────────────────────────────────────
#  REDIS — CARRELLO
# ─────────────────────────────────────────────────
CARRELLO_TTL = int(os.getenv('CARRELLO_TTL_ORE', 72)) * 3600   # secondi

def chiave_carrello(id_utente):
    return f'carrello:{id_utente}'


def get_carrello(id_utente):
    """Restituisce dict {id_prodotto: quantita} dal carrello Redis."""
    r = get_redis()
    if not r:
        return {}
    raw = r.hgetall(chiave_carrello(id_utente))
    return {k: int(v) for k, v in raw.items()}


def set_carrello_item(id_utente, id_prodotto, quantita):
    """Aggiunge/aggiorna un prodotto nel carrello. Azzera se quantita <= 0."""
    r = get_redis()
    if not r:
        return False
    key = chiave_carrello(id_utente)
    if quantita <= 0:
        r.hdel(key, str(id_prodotto))
    else:
        r.hset(key, str(id_prodotto), quantita)
        r.expire(key, CARRELLO_TTL)
    return True


def rimuovi_carrello_item(id_utente, id_prodotto):
    r = get_redis()
    if not r:
        return False
    r.hdel(chiave_carrello(id_utente), str(id_prodotto))
    return True


def svuota_carrello_redis(id_utente):
    r = get_redis()
    if not r:
        return False
    r.delete(chiave_carrello(id_utente))
    return True


def conta_carrello(id_utente):
    """Numero totale di articoli nel carrello."""
    carrello = get_carrello(id_utente)
    return sum(carrello.values())

# ─────────────────────────────────────────────────
#  REDIS — COUPON
# ─────────────────────────────────────────────────
def chiave_coupon(codice):
    return f'coupon:{codice.upper()}'


def chiave_coupon_utente(id_utente, codice):
    return f'coupon_usato:{id_utente}:{codice.upper()}'


def get_coupon(codice):
    """Restituisce dict con i dati del coupon o None se non esiste/scaduto."""
    r = get_redis()
    if not r:
        return None
    raw = r.hgetall(chiave_coupon(codice))
    if not raw:
        return None
    return raw


def crea_coupon(codice, sconto, scadenza, utilizzi):
    """Crea un coupon su Redis con TTL calcolato dalla data di scadenza."""
    r = get_redis()
    if not r:
        return False

    key = chiave_coupon(codice)

    # Scrittura hash (compatibile con tutte le versioni)
    r.hset(key, 'sconto', sconto)
    r.hset(key, 'scadenza', scadenza)
    r.hset(key, 'utilizzi_disponibili', utilizzi)

    # Calcola TTL fino a scadenza
    try:
        exp = datetime.datetime.strptime(scadenza, '%Y-%m-%d')
        ttl = int((exp - datetime.datetime.now()).total_seconds())
        if ttl > 0:
            r.expire(key, ttl)
    except ValueError:
        pass

    return True


def usa_coupon(codice, id_utente):
    """
    Valida e scala un utilizzo dal coupon.
    Ritorna (True, sconto%) oppure (False, messaggio_errore).
    """
    r = get_redis()
    if not r:
        return False, 'Redis non disponibile'

    dati = get_coupon(codice)
    if not dati:
        return False, 'Coupon non valido o scaduto'

    # Controlla se l'utente ha già usato questo coupon
    if r.exists(chiave_coupon_utente(id_utente, codice)):
        return False, 'Hai già utilizzato questo coupon'

    utilizzi = int(dati.get('utilizzi_disponibili', 0))
    if utilizzi <= 0:
        return False, 'Coupon esaurito'

    scadenza = dati.get('scadenza', '')
    try:
        exp = datetime.datetime.strptime(scadenza, '%Y-%m-%d')
        if datetime.datetime.now() > exp:
            return False, 'Coupon scaduto'
    except ValueError:
        pass

    return True, int(dati.get('sconto', 0))


def scala_utilizzo_coupon(codice, id_utente):
    """Scala un utilizzo e registra l'uso da parte dell'utente."""
    r = get_redis()
    if not r:
        return False
    r.hincrby(chiave_coupon(codice), 'utilizzi_disponibili', -1)
    # Segna coupon come usato da questo utente (TTL 365 giorni)
    r.setex(chiave_coupon_utente(id_utente, codice), 60 * 60 * 24 * 365, '1')
    return True


def lista_coupon():
    """Restituisce lista di tutti i coupon salvati su Redis."""
    r = get_redis()
    if not r:
        return []
    try:
        chiavi = [k for k in r.keys('coupon:*') if not k.startswith('coupon_usato:')]
        risultati = []
        for k in chiavi:
            try:
                dati = dict(r.hgetall(k))
                dati['codice'] = k.split(':', 1)[1]
                dati.setdefault('sconto', '0')
                dati.setdefault('scadenza', '—')
                dati.setdefault('utilizzi_disponibili', '0')
                risultati.append(dati)
            except Exception:
                continue
        return risultati
    except Exception:
        return []


def elimina_coupon(codice):
    r = get_redis()
    if not r:
        return False
    r.delete(chiave_coupon(codice))
    return True

# ─────────────────────────────────────────────────
#  SETUP REDIS  (chiamato all'avvio)
# ─────────────────────────────────────────────────
def setup_redis():
    """
    Inizializza le strutture dati di base su Redis.
    Crea il coupon WELCOME10 se non esiste già.
    """
    r = get_redis()
    if not r:
        print('[WARN] Redis non raggiungibile — setup Redis saltato.')
        return
    # Coupon di benvenuto (se non esiste)
    if not r.exists('coupon:WELCOME10'):
        scadenza = (datetime.datetime.now() + datetime.timedelta(days=365)).strftime('%Y-%m-%d')
        crea_coupon('WELCOME10', 10, scadenza, 1000)
        print('[INFO] Coupon WELCOME10 creato su Redis.')
    print('[INFO] Setup Redis completato.')

# ─────────────────────────────────────────────────
#  MIGRAZIONE / SETUP DATABASE
# ─────────────────────────────────────────────────
TABELLE = {
    'metodi_pagamenti': """
        CREATE TABLE IF NOT EXISTS metodi_pagamenti (
            id_metodo_pagamento INT AUTO_INCREMENT PRIMARY KEY,
            metodo              VARCHAR(100) NOT NULL,
            tipo_carta          VARCHAR(50)  NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    """,
    'categorie': """
        CREATE TABLE IF NOT EXISTS categorie (
            id_categoria  INT AUTO_INCREMENT PRIMARY KEY,
            nome_c        VARCHAR(100) NOT NULL,
            fk_categoria_c INT NULL,
            FOREIGN KEY (fk_categoria_c) REFERENCES categorie(id_categoria)
                ON DELETE SET NULL ON UPDATE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    """,
    'corrieri': """
        CREATE TABLE IF NOT EXISTS corrieri (
            id_corriere      INT AUTO_INCREMENT PRIMARY KEY,
            compagnia        VARCHAR(100)   NOT NULL,
            numero_corriere  VARCHAR(50)    NOT NULL,
            aree_disponibili JSON           NULL,
            costo_per_km     DECIMAL(10,2)  NOT NULL DEFAULT 0.00,
            costo_al_kg      DECIMAL(10,2)  NOT NULL DEFAULT 0.00
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    """,
    'utenti': """
        CREATE TABLE IF NOT EXISTS utenti (
            id_utente          INT AUTO_INCREMENT PRIMARY KEY,
            username_u         VARCHAR(50)  NOT NULL UNIQUE,
            password_u         VARCHAR(255) NOT NULL,
            email_u            VARCHAR(150) NOT NULL UNIQUE,
            tipo_u             BOOLEAN      NOT NULL DEFAULT 0,
            fk_metodo_pagamento INT         NULL,
            FOREIGN KEY (fk_metodo_pagamento) REFERENCES metodi_pagamenti(id_metodo_pagamento)
                ON DELETE SET NULL ON UPDATE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    """,
    'prodotti': """
        CREATE TABLE IF NOT EXISTS prodotti (
            id_prodotto          INT AUTO_INCREMENT PRIMARY KEY,
            nome_p               VARCHAR(150) NOT NULL,
            descrizione_p        TEXT         NULL,
            link_immagine        TEXT         NULL,
            prezzo               DECIMAL(10,2) NOT NULL,
            quantita_disponibile INT          NOT NULL DEFAULT 0,
            fk_categoria         INT          NULL,
            FOREIGN KEY (fk_categoria) REFERENCES categorie(id_categoria)
                ON DELETE SET NULL ON UPDATE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    """,
    'ordini': """
        CREATE TABLE IF NOT EXISTS ordini (
            id_ordine        INT AUTO_INCREMENT PRIMARY KEY,
            numero_ordine    VARCHAR(50)   NOT NULL,
            data_ordine      DATE          NOT NULL,
            stato_ordine     VARCHAR(50)   NOT NULL DEFAULT 'In attesa',
            pagamento_ordine BOOLEAN       NOT NULL DEFAULT 0,
            fk_utente        INT           NOT NULL,
            fk_prodotto      INT           NOT NULL,
            FOREIGN KEY (fk_utente)   REFERENCES utenti(id_utente)   ON DELETE CASCADE ON UPDATE CASCADE,
            FOREIGN KEY (fk_prodotto) REFERENCES prodotti(id_prodotto) ON DELETE CASCADE ON UPDATE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    """,
    'spedizioni': """
        CREATE TABLE IF NOT EXISTS spedizioni (
            fk_ordine           INT  NOT NULL,
            fk_corriere         INT  NOT NULL,
            data_consegna       DATE NULL,
            tracking_spedizione TEXT NULL,
            PRIMARY KEY (fk_ordine, fk_corriere),
            FOREIGN KEY (fk_ordine)   REFERENCES ordini(id_ordine)     ON DELETE CASCADE ON UPDATE CASCADE,
            FOREIGN KEY (fk_corriere) REFERENCES corrieri(id_corriere)  ON DELETE CASCADE ON UPDATE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    """
}

ADMIN_DEFAULT_HASH = '60fe74406e7f353ed979f350f2fbb6a2e8690a5fa7d1b0c32983d1d8b3f95f67'


def inserisci_admin_default(cur, cnx):
    """Crea admin di default se la tabella utenti e' vuota."""
    cur.execute('SELECT COUNT(*) FROM utenti')
    if cur.fetchone()[0] == 0:
        cur.execute(
            "INSERT INTO utenti (username_u, password_u, email_u, tipo_u) "
            "VALUES ('admin', %s, 'admin@shopnova.it', 1)",
            (ADMIN_DEFAULT_HASH,)
        )
        cnx.commit()
        print('[INFO] Admin creato: username=admin  password=Admin1234')


DATI_DEFAULT = {
    'metodi_pagamenti': [
        "INSERT IGNORE INTO metodi_pagamenti (metodo, tipo_carta) VALUES ('Carta di credito', 'Visa')",
        "INSERT IGNORE INTO metodi_pagamenti (metodo, tipo_carta) VALUES ('Carta di credito', 'Mastercard')",
        "INSERT IGNORE INTO metodi_pagamenti (metodo, tipo_carta) VALUES ('Carta di debito', NULL)",
        "INSERT IGNORE INTO metodi_pagamenti (metodo, tipo_carta) VALUES ('PayPal', NULL)",
        "INSERT IGNORE INTO metodi_pagamenti (metodo, tipo_carta) VALUES ('Bonifico bancario', NULL)",
    ],
    'categorie': [
        "INSERT IGNORE INTO categorie (nome_c, fk_categoria_c) VALUES ('Elettronica', NULL)",
        "INSERT IGNORE INTO categorie (nome_c, fk_categoria_c) VALUES ('Abbigliamento', NULL)",
        "INSERT IGNORE INTO categorie (nome_c, fk_categoria_c) VALUES ('Casa e giardino', NULL)",
        "INSERT IGNORE INTO categorie (nome_c, fk_categoria_c) VALUES ('Sport', NULL)",
        "INSERT IGNORE INTO categorie (nome_c, fk_categoria_c) VALUES ('Libri', NULL)",
    ],
    'corrieri': [
        "INSERT IGNORE INTO corrieri (compagnia, numero_corriere, aree_disponibili, costo_per_km, costo_al_kg) VALUES ('Poste Italiane', 'IT123456', '[\"Italia\"]', 0.50, 1.00)",
        "INSERT IGNORE INTO corrieri (compagnia, numero_corriere, aree_disponibili, costo_per_km, costo_al_kg) VALUES ('DHL', 'DH789012', '[\"Europa\"]', 0.75, 1.50)",
        "INSERT IGNORE INTO corrieri (compagnia, numero_corriere, aree_disponibili, costo_per_km, costo_al_kg) VALUES ('UPS', 'UP345678', '[\"Mondiale\"]', 1.00, 2.00)",
    ]
}


def crea_database_se_mancante():
    """Crea il database 'ecommerce' se non esiste già."""
    try:
        cnx = mysql.connector.connect(
            host=os.getenv('MYSQL_HOST', '127.0.0.1'),
            user=os.getenv('MYSQL_USER', 'root'),
            password=os.getenv('MYSQL_PASSWORD', ''),
            connection_timeout=5
        )
        with cnx.cursor() as cur:
            cur.execute("CREATE DATABASE IF NOT EXISTS ecommerce CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci")
        cnx.commit()
        print('[INFO] Database ecommerce verificato/creato.')
    except MySQLError as e:
        print(f'[ERROR] Impossibile creare il database: {e}')
    finally:
        if 'cnx' in locals():
            cnx.close()


def migrazione_db():
    """
    1. Crea il database ecommerce se non esiste.
    2. Crea tabelle, inserisce dati minimi e admin di default.
    3. Corregge la collation di password_u.
    """
    crea_database_se_mancante()
    cnx = get_db()
    if not cnx:
        print('[WARN] MySQL non raggiungibile — migrazione saltata.')
        return

    try:
        with cnx.cursor() as cur:
            for nome, sql in TABELLE.items():
                cur.execute(sql)
                print(f'[INFO] Tabella "{nome}" verificata/creata.')
            cnx.commit()

            # ── FIX CRITICO: imposta password_u come BINARY (case-sensitive) ──
            # La collation di default utf8mb4_general_ci è case-insensitive:
            # confronta 'abc' == 'ABC', rendendo inutile il confronto degli hash.
            # Con COLLATE utf8mb4_bin il confronto è esatto, byte per byte.
            cur.execute("""
                SELECT COLLATION_NAME
                FROM information_schema.COLUMNS
                WHERE TABLE_SCHEMA = DATABASE()
                  AND TABLE_NAME   = 'utenti'
                  AND COLUMN_NAME  = 'password_u'
            """)
            row = cur.fetchone()
            if row and row[0] != 'utf8mb4_bin':
                cur.execute("""
                    ALTER TABLE utenti
                    MODIFY COLUMN password_u VARCHAR(255)
                    CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL
                """)
                cnx.commit()
                print('[INFO] Colonna password_u aggiornata a utf8mb4_bin (case-sensitive).')
            else:
                print('[INFO] Colonna password_u già corretta.')

            # Dati di default
            for tabella, query_list in DATI_DEFAULT.items():
                cur.execute(f'SELECT COUNT(*) FROM {tabella}')
                count = cur.fetchone()[0]
                if count == 0:
                    for q in query_list:
                        cur.execute(q)
                    cnx.commit()
                    print(f'[INFO] Dati default inseriti in "{tabella}".')
            inserisci_admin_default(cur, cnx)

        print('[INFO] Migrazione database completata.')
    except MySQLError as e:
        print(f'[ERROR] Migrazione fallita: {e}')
    finally:
        cnx.close()

# ─────────────────────────────────────────────────
#  CONTEXT PROCESSOR  (variabili globali nei template)
# ─────────────────────────────────────────────────
@app.context_processor
def inject_globals():
    cart_count = 0
    if session.get('utente'):
        cart_count = conta_carrello(session['utente'])
    return {'cart_count': cart_count}

# ─────────────────────────────────────────────────
#  DECORATOR — login required
# ─────────────────────────────────────────────────
from functools import wraps

def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not session.get('utente'):
            flash('Devi essere loggato per accedere a questa pagina.', 'warning')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated


def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not session.get('utente'):
            flash('Accesso riservato agli amministratori.', 'warning')
            return redirect(url_for('login'))
        if not session.get('tipo_u'):
            flash('Non hai i permessi per questa operazione.', 'danger')
            return redirect(url_for('index'))
        return f(*args, **kwargs)
    return decorated

# ─────────────────────────────────────────────────
#  GESTIONE ERRORI GLOBALE
# ─────────────────────────────────────────────────
@app.errorhandler(404)
def not_found(e):
    return render_template('errore.html',
        codice=404,
        titolo='Pagina non trovata',
        messaggio='La pagina che cerchi non esiste o è stata spostata.'
    ), 404


@app.errorhandler(403)
def forbidden(e):
    return render_template('errore.html',
        codice=403,
        titolo='Accesso negato',
        messaggio='Non hai i permessi per accedere a questa risorsa.'
    ), 403


@app.errorhandler(500)
def server_error(e):
    return render_template('errore.html',
        codice=500,
        titolo='Errore interno',
        messaggio='Si è verificato un errore imprevisto. Riprova tra poco.'
    ), 500

# ─────────────────────────────────────────────────
#  ROUTE — HOME
# ─────────────────────────────────────────────────
@app.route('/')
def index():
    try:
        # Controlla Redis e avvisa l'utente se non è avviato
        if get_redis() is None:
            flash(
                'Ops! Redis non è avviato — carrello e coupon non sono disponibili. '
                'Avvia Redis e ricarica la pagina.',
                'warning'
            )

        prodotti = query_fetchall("""
            SELECT p.*, c.nome_c
            FROM prodotti p
            LEFT JOIN categorie c ON p.fk_categoria = c.id_categoria
            ORDER BY p.id_prodotto DESC
            LIMIT 8
        """)
        categorie = query_fetchall('SELECT * FROM categorie ORDER BY nome_c')
        if prodotti is None:
            flash('Database non disponibile. Alcune funzionalità potrebbero non funzionare.', 'warning')
            prodotti = []
        if categorie is None:
            categorie = []
        return render_template('index.html', prodotti=prodotti, categorie=categorie)
    except Exception:
        return render_template('errore.html',
            codice=500, titolo='Errore', messaggio='Errore imprevisto.'), 500

# ─────────────────────────────────────────────────
#  ROUTE — CATALOGO
# ─────────────────────────────────────────────────
@app.route('/catalogo')
def catalogo():
    try:
        q            = request.args.get('q', '').strip()
        cat_id       = request.args.get('categoria', '').strip()
        prezzo_min   = request.args.get('prezzo_min', '').strip()
        prezzo_max   = request.args.get('prezzo_max', '').strip()
        solo_disp    = request.args.get('disponibile', '')
        ordine       = request.args.get('ordine', '')

        sql = """
            SELECT p.*, c.nome_c
            FROM prodotti p
            LEFT JOIN categorie c ON p.fk_categoria = c.id_categoria
            WHERE 1=1
        """
        params = []

        if q:
            sql += ' AND (p.nome_p LIKE %s OR p.descrizione_p LIKE %s)'
            params += [f'%{q}%', f'%{q}%']
        if cat_id:
            sql += ' AND p.fk_categoria = %s'
            params.append(cat_id)
        if prezzo_min:
            sql += ' AND p.prezzo >= %s'
            params.append(prezzo_min)
        if prezzo_max:
            sql += ' AND p.prezzo <= %s'
            params.append(prezzo_max)
        if solo_disp:
            sql += ' AND p.quantita_disponibile > 0'

        ordini_map = {
            'prezzo_asc':  ' ORDER BY p.prezzo ASC',
            'prezzo_desc': ' ORDER BY p.prezzo DESC',
            'nome_asc':    ' ORDER BY p.nome_p ASC',
        }
        sql += ordini_map.get(ordine, ' ORDER BY p.id_prodotto DESC')

        prodotti  = query_fetchall(sql, params) or []
        categorie = query_fetchall('SELECT * FROM categorie ORDER BY nome_c') or []

        categoria_attiva = None
        if cat_id:
            categoria_attiva = query_fetchone(
                'SELECT * FROM categorie WHERE id_categoria=%s', (cat_id,))

        categoria_path = get_categoria_path(cat_id) if cat_id else []
        return render_template('catalogo.html',
            prodotti=prodotti,
            categorie=categorie,
            categoria_attiva=categoria_attiva,
            categoria_path=categoria_path)
    except Exception:
        flash('Errore nel caricamento del catalogo.', 'danger')
        return redirect(url_for('index'))

# ─────────────────────────────────────────────────
#  ROUTE — AUTH: LOGIN
# ─────────────────────────────────────────────────
@app.route('/login', methods=['GET', 'POST'])
def login():
    if session.get('utente'):
        return redirect(url_for('index'))

    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')

        if not username or not password:
            flash('Inserisci username e password.', 'warning')
            return redirect(url_for('login'))

        # 1. Verifica che il DB sia raggiungibile
        if get_db() is None:
            flash('Database non disponibile. Riprova più tardi.', 'danger')
            return redirect(url_for('login'))

        # 2. Cerca l'utente solo per username
        utente = query_fetchone(
            'SELECT * FROM utenti WHERE username_u=%s',
            (username,)
        )

        # 3. Confronta la password in Python (evita problemi di collation/charset MySQL)
        if not utente or utente['password_u'] != hash_password(password):
            flash('Username o password errati.', 'danger')
            return redirect(url_for('login'))

        session['utente']     = utente['id_utente']
        session['username_u'] = utente['username_u']
        session['tipo_u']     = bool(utente['tipo_u'])
        flash(f'Bentornato, {utente["username_u"]}!', 'success')
        return redirect(url_for('index'))

    return render_template('login.html')

# ─────────────────────────────────────────────────
#  ROUTE — AUTH: REGISTRAZIONE
# ─────────────────────────────────────────────────
@app.route('/registrazione', methods=['GET', 'POST'])
def registrazione():
    if session.get('utente'):
        return redirect(url_for('index'))

    metodi = query_fetchall('SELECT * FROM metodi_pagamenti') or []

    if request.method == 'POST':
        username  = request.form.get('username', '').strip()
        email     = request.form.get('email', '').strip()
        password  = request.form.get('password', '')
        metodo_id = request.form.get('metodo_pagamento', '').strip() or None
        tipo_carta = request.form.get('tipo_carta', '').strip() or None

        # Validazione
        if len(username) < 3 or len(username) > 50:
            flash('Username: minimo 3, massimo 50 caratteri.', 'danger')
            return render_template('registrazione.html', metodi_pagamento=metodi)
        if len(password) < 6:
            flash('Password: minimo 6 caratteri.', 'danger')
            return render_template('registrazione.html', metodi_pagamento=metodi)
        if '@' not in email:
            flash('Email non valida.', 'danger')
            return render_template('registrazione.html', metodi_pagamento=metodi)

        # Controlla duplicati
        esistente = query_fetchone(
            'SELECT id_utente FROM utenti WHERE username_u=%s OR email_u=%s',
            (username, email)
        )
        if esistente:
            flash('Username o email già in uso.', 'danger')
            return render_template('registrazione.html', metodi_pagamento=metodi)

        # Gestione metodo di pagamento con tipo_carta
        fk_metodo = None
        if metodo_id:
            metodo_scelto = query_fetchone(
                'SELECT * FROM metodi_pagamenti WHERE id_metodo_pagamento=%s', (metodo_id,))
            richiede_carta = metodo_scelto and metodo_scelto['metodo'] and \
                             ('carta' in metodo_scelto['metodo'].lower() or 'card' in metodo_scelto['metodo'].lower())

            if richiede_carta and not tipo_carta:
                flash('Indica il tipo di carta per il metodo selezionato.', 'warning')
                return render_template('registrazione.html', metodi_pagamento=metodi)

            if richiede_carta and tipo_carta:
                # Crea un nuovo record metodo con il tipo_carta specifico
                new_id = query_lastrowid(
                    'INSERT INTO metodi_pagamenti (metodo, tipo_carta) VALUES (%s, %s)',
                    (metodo_scelto['metodo'], tipo_carta)
                )
                fk_metodo = new_id
            else:
                fk_metodo = metodo_id

        ok = query_commit(
            'INSERT INTO utenti (username_u, password_u, email_u, tipo_u, fk_metodo_pagamento) VALUES (%s,%s,%s,0,%s)',
            (username, hash_password(password), email, fk_metodo)
        )
        if not ok:
            flash('Errore durante la registrazione. Riprova.', 'danger')
            return render_template('registrazione.html', metodi_pagamento=metodi)

        flash('Account creato! Puoi ora effettuare il login.', 'success')
        return redirect(url_for('login'))

    return render_template('registrazione.html', metodi_pagamento=metodi)

# ─────────────────────────────────────────────────
#  ROUTE — LOGOUT
# ─────────────────────────────────────────────────
@app.route('/logout')
@login_required
def logout():
    session.clear()
    flash('Hai effettuato il logout.', 'info')
    return redirect(url_for('index'))

# ─────────────────────────────────────────────────
#  ROUTE — PROFILO
# ─────────────────────────────────────────────────
@app.route('/profilo')
@login_required
def profilo():
    utente  = query_fetchone('SELECT * FROM utenti WHERE id_utente=%s', (session['utente'],))
    metodi  = query_fetchall('SELECT * FROM metodi_pagamenti') or []
    if not utente:
        flash('Utente non trovato.', 'danger')
        return redirect(url_for('index'))
    return render_template('profilo.html', utente=utente, metodi_pagamento=metodi)


@app.route('/aggiorna-profilo', methods=['POST'])
@login_required
def aggiorna_profilo():
    username       = request.form.get('username', '').strip()
    email          = request.form.get('email', '').strip()
    nuova_password = request.form.get('nuova_password', '').strip()
    metodo_id      = request.form.get('metodo_pagamento', '').strip() or None

    if len(username) < 3:
        flash('Username troppo corto.', 'danger')
        return redirect(url_for('profilo'))

    if nuova_password and len(nuova_password) < 6:
        flash('La nuova password deve avere almeno 6 caratteri.', 'danger')
        return redirect(url_for('profilo'))

    if nuova_password:
        ok = query_commit(
            'UPDATE utenti SET username_u=%s, email_u=%s, password_u=%s, fk_metodo_pagamento=%s WHERE id_utente=%s',
            (username, email, hash_password(nuova_password), metodo_id, session['utente'])
        )
    else:
        ok = query_commit(
            'UPDATE utenti SET username_u=%s, email_u=%s, fk_metodo_pagamento=%s WHERE id_utente=%s',
            (username, email, metodo_id, session['utente'])
        )

    if ok:
        session['username_u'] = username
        flash('Profilo aggiornato con successo.', 'success')
    else:
        flash('Errore durante l\'aggiornamento del profilo.', 'danger')

    return redirect(url_for('profilo'))

# ─────────────────────────────────────────────────
#  ROUTE — CARRELLO
# ─────────────────────────────────────────────────
@app.route('/carrello')
@login_required
def carrello():
    id_utente = session['utente']
    cart      = get_carrello(id_utente)

    prodotti_carrello = []
    totale_base = 0.0

    if cart:
        ids = list(cart.keys())
        placeholders = ','.join(['%s'] * len(ids))
        prodotti_db = query_fetchall(
            f'SELECT p.*, c.nome_c FROM prodotti p LEFT JOIN categorie c ON p.fk_categoria=c.id_categoria WHERE p.id_prodotto IN ({placeholders})',
            ids
        ) or []

        for p in prodotti_db:
            qty = cart.get(str(p['id_prodotto']), 0)
            p['quantita'] = qty
            prodotti_carrello.append(p)
            totale_base += float(p['prezzo']) * qty

    # Coupon dalla sessione
    coupon_applicato   = session.get('coupon_codice')
    sconto_percentuale = session.get('coupon_sconto', 0)
    sconto_importo     = round(totale_base * sconto_percentuale / 100, 2) if sconto_percentuale else 0

    # Spedizione
    soglia_gratuita = float(os.getenv('SPEDIZIONE_GRATUITA_SOGLIA', 49))
    costo_spedizione = 0 if totale_base >= soglia_gratuita else float(os.getenv('COSTO_SPEDIZIONE', 5.99))

    totale_finale = round(totale_base - sconto_importo + costo_spedizione, 2)

    return render_template('carrello.html',
        prodotti_carrello=prodotti_carrello,
        totale_base=totale_base,
        coupon_applicato=coupon_applicato,
        sconto_percentuale=sconto_percentuale,
        sconto_importo=sconto_importo,
        totale_finale=totale_finale
    )


@app.route('/aggiungi-al-carrello', methods=['POST'])
@login_required
def aggiungi_al_carrello():
    id_prodotto = request.form.get('id_prodotto', '').strip()
    quantita    = int(request.form.get('quantita', 1))

    if not id_prodotto:
        flash('Prodotto non valido.', 'danger')
        return redirect(url_for('catalogo'))

    # Verifica disponibilità
    prodotto = query_fetchone(
        'SELECT * FROM prodotti WHERE id_prodotto=%s', (id_prodotto,))
    if not prodotto:
        flash('Prodotto non trovato.', 'danger')
        return redirect(url_for('catalogo'))
    if prodotto['quantita_disponibile'] <= 0:
        flash('Prodotto non disponibile.', 'warning')
        return redirect(url_for('catalogo'))

    id_utente = session['utente']
    cart = get_carrello(id_utente)
    qty_attuale = cart.get(str(id_prodotto), 0)
    nuova_qty   = qty_attuale + quantita

    if nuova_qty > prodotto['quantita_disponibile']:
        flash(f'Disponibili solo {prodotto["quantita_disponibile"]} pezzi.', 'warning')
        return redirect(url_for('catalogo'))

    r = get_redis()
    if not r:
        flash('Carrello non disponibile (Redis offline).', 'danger')
        return redirect(url_for('catalogo'))

    set_carrello_item(id_utente, id_prodotto, nuova_qty)
    flash(f'"{prodotto["nome_p"]}" aggiunto al carrello.', 'success')
    return redirect(request.referrer or url_for('catalogo'))


@app.route('/aggiorna-carrello', methods=['POST'])
@login_required
def aggiorna_carrello():
    id_prodotto = request.form.get('id_prodotto', '').strip()
    azione      = request.form.get('azione', '')
    id_utente   = session['utente']

    cart    = get_carrello(id_utente)
    qty     = cart.get(str(id_prodotto), 0)

    if azione == 'incrementa':
        prodotto = query_fetchone('SELECT quantita_disponibile FROM prodotti WHERE id_prodotto=%s', (id_prodotto,))
        if prodotto and qty < prodotto['quantita_disponibile']:
            set_carrello_item(id_utente, id_prodotto, qty + 1)
        else:
            flash('Quantità massima raggiunta.', 'warning')
    elif azione == 'decrementa':
        set_carrello_item(id_utente, id_prodotto, qty - 1)

    return redirect(url_for('carrello'))


@app.route('/rimuovi-dal-carrello', methods=['POST'])
@login_required
def rimuovi_dal_carrello():
    id_prodotto = request.form.get('id_prodotto', '').strip()
    rimuovi_carrello_item(session['utente'], id_prodotto)
    flash('Prodotto rimosso dal carrello.', 'info')
    return redirect(url_for('carrello'))


@app.route('/svuota-carrello', methods=['POST'])
@login_required
def svuota_carrello():
    svuota_carrello_redis(session['utente'])
    session.pop('coupon_codice', None)
    session.pop('coupon_sconto', None)
    flash('Carrello svuotato.', 'info')
    return redirect(url_for('carrello'))

# ─────────────────────────────────────────────────
#  ROUTE — COUPON
# ─────────────────────────────────────────────────
@app.route('/applica-coupon', methods=['POST'])
@login_required
def applica_coupon():
    codice = request.form.get('codice_coupon', '').strip().upper()
    if not codice:
        flash('Inserisci un codice coupon.', 'warning')
        return redirect(url_for('carrello'))

    valido, risultato = usa_coupon(codice, session['utente'])
    if valido:
        session['coupon_codice'] = codice
        session['coupon_sconto'] = risultato
        flash(f'Coupon applicato! Sconto del {risultato}%.', 'success')
    else:
        flash(f'Coupon non valido: {risultato}', 'danger')

    return redirect(url_for('carrello'))


@app.route('/rimuovi-coupon')
@login_required
def rimuovi_coupon():
    session.pop('coupon_codice', None)
    session.pop('coupon_sconto', None)
    flash('Coupon rimosso.', 'info')
    return redirect(url_for('carrello'))

# ─────────────────────────────────────────────────
#  ROUTE — CHECKOUT
# ─────────────────────────────────────────────────
@app.route('/checkout', methods=['POST'])
@login_required
def checkout():
    id_utente = session['utente']
    cart      = get_carrello(id_utente)

    if not cart:
        flash('Il carrello è vuoto.', 'warning')
        return redirect(url_for('carrello'))

    # Verifica prodotti disponibili
    ids = list(cart.keys())
    placeholders = ','.join(['%s'] * len(ids))
    prodotti_db = query_fetchall(
        f'SELECT * FROM prodotti WHERE id_prodotto IN ({placeholders})', ids
    ) or []

    mappa_prodotti = {str(p['id_prodotto']): p for p in prodotti_db}

    for id_p, qty in cart.items():
        p = mappa_prodotti.get(str(id_p))
        if not p or p['quantita_disponibile'] < qty:
            nome = p['nome_p'] if p else f'ID {id_p}'
            flash(f'Quantità insufficiente per: {nome}', 'danger')
            return redirect(url_for('carrello'))

    # Crea ordine
    numero_ordine = str(uuid.uuid4())[:8].upper()
    data_oggi     = datetime.date.today()
    coupon_codice = session.get('coupon_codice')

    cnx = get_db()
    if not cnx:
        flash('Database non disponibile. Impossibile completare l\'ordine.', 'danger')
        return redirect(url_for('carrello'))

    try:
        with cnx.cursor() as cur:
            for id_p, qty in cart.items():
                cur.execute(
                    'INSERT INTO ordini (numero_ordine, data_ordine, stato_ordine, pagamento_ordine, fk_utente, fk_prodotto) VALUES (%s,%s,%s,0,%s,%s)',
                    (numero_ordine, data_oggi, 'In attesa', id_utente, id_p)
                )
                # Scala disponibilità
                cur.execute(
                    'UPDATE prodotti SET quantita_disponibile = quantita_disponibile - %s WHERE id_prodotto=%s',
                    (qty, id_p)
                )
            cnx.commit()

        # Scala utilizzo coupon
        if coupon_codice:
            scala_utilizzo_coupon(coupon_codice, id_utente)

        # Svuota carrello e coupon sessione
        svuota_carrello_redis(id_utente)
        session.pop('coupon_codice', None)
        session.pop('coupon_sconto', None)

        flash(f'Ordine #{numero_ordine} effettuato con successo!', 'success')
        return redirect(url_for('ordini'))

    except MySQLError as e:
        cnx.rollback()
        flash('Errore durante il checkout. Riprova.', 'danger')
        return redirect(url_for('carrello'))
    finally:
        cnx.close()

# ─────────────────────────────────────────────────
#  ROUTE — ORDINI UTENTE
# ─────────────────────────────────────────────────
@app.route('/ordini')
@login_required
def ordini():
    rows = query_fetchall("""
        SELECT o.*, p.nome_p, p.link_immagine, p.prezzo,
               c.nome_c, sp.tracking_spedizione, sp.data_consegna
        FROM ordini o
        JOIN prodotti p ON o.fk_prodotto = p.id_prodotto
        LEFT JOIN categorie c ON p.fk_categoria = c.id_categoria
        LEFT JOIN spedizioni sp ON sp.fk_ordine = o.id_ordine
        WHERE o.fk_utente = %s
        ORDER BY o.data_ordine DESC, o.numero_ordine
    """, (session['utente'],)) or []

    # Raggruppa per numero_ordine
    ordini_grouped = {}
    for row in rows:
        n = row['numero_ordine']
        if n not in ordini_grouped:
            ordini_grouped[n] = []
        ordini_grouped[n].append(row)

    return render_template('ordini.html', ordini_grouped=ordini_grouped)

# ─────────────────────────────────────────────────
#  ROUTE — ADMIN: DASHBOARD
# ─────────────────────────────────────────────────
@app.route('/admin')
@admin_required
def admin_dashboard():
    stats = {
        'num_prodotti':  (query_fetchone('SELECT COUNT(*) AS n FROM prodotti') or {}).get('n', 0),
        'num_utenti':    (query_fetchone('SELECT COUNT(*) AS n FROM utenti') or {}).get('n', 0),
        'num_ordini':    (query_fetchone('SELECT COUNT(DISTINCT numero_ordine) AS n FROM ordini') or {}).get('n', 0),
        'num_categorie': (query_fetchone('SELECT COUNT(*) AS n FROM categorie') or {}).get('n', 0),
    }
    ultimi_ordini = query_fetchall("""
        SELECT o.*, u.username_u, p.nome_p
        FROM ordini o
        JOIN utenti u ON o.fk_utente = u.id_utente
        JOIN prodotti p ON o.fk_prodotto = p.id_prodotto
        ORDER BY o.data_ordine DESC, o.id_ordine DESC
        LIMIT 10
    """) or []
    return render_template('admin/dashboard.html', stats=stats, ultimi_ordini=ultimi_ordini)

# ─────────────────────────────────────────────────
#  ROUTE — ADMIN: PRODOTTI
# ─────────────────────────────────────────────────
@app.route('/admin/prodotti')
@admin_required
def admin_prodotti():
    prodotti  = query_fetchall("""
        SELECT p.*, c.nome_c
        FROM prodotti p LEFT JOIN categorie c ON p.fk_categoria=c.id_categoria
        ORDER BY p.id_prodotto DESC
    """) or []
    categorie = query_fetchall('SELECT * FROM categorie ORDER BY nome_c') or []
    return render_template('admin/prodotti.html', prodotti=prodotti, categorie=categorie)


@app.route('/admin/prodotti/aggiungi', methods=['POST'])
@admin_required
def admin_aggiungi_prodotto():
    nome        = request.form.get('nome_p', '').strip()
    descrizione = request.form.get('descrizione_p', '').strip()
    link_img    = normalizza_immagine(request.form.get('link_immagine', ''))
    prezzo      = request.form.get('prezzo', '0')
    qty         = request.form.get('quantita_disponibile', '0')
    fk_cat      = request.form.get('fk_categoria', '').strip() or None

    if not nome or not prezzo:
        flash('Nome e prezzo sono obbligatori.', 'danger')
        return redirect(url_for('admin_prodotti'))

    try:
        prezzo = float(prezzo)
        qty    = int(qty)
    except ValueError:
        flash('Prezzo o quantità non validi.', 'danger')
        return redirect(url_for('admin_prodotti'))

    ok = query_commit(
        'INSERT INTO prodotti (nome_p, descrizione_p, link_immagine, prezzo, quantita_disponibile, fk_categoria) VALUES (%s,%s,%s,%s,%s,%s)',
        (nome, descrizione, link_img, prezzo, qty, fk_cat)
    )
    if ok:
        flash('Prodotto aggiunto con successo.', 'success')
    else:
        flash('Errore durante l\'aggiunta del prodotto.', 'danger')
    return redirect(url_for('admin_prodotti'))


@app.route('/admin/prodotti/modifica', methods=['POST'])
@admin_required
def admin_modifica_prodotto():
    id_p        = request.form.get('id_prodotto')
    nome        = request.form.get('nome_p', '').strip()
    descrizione = request.form.get('descrizione_p', '').strip()
    link_img    = normalizza_immagine(request.form.get('link_immagine', ''))
    prezzo      = request.form.get('prezzo', '0')
    qty         = request.form.get('quantita_disponibile', '0')
    fk_cat      = request.form.get('fk_categoria', '').strip() or None

    try:
        prezzo = float(prezzo)
        qty    = int(qty)
    except ValueError:
        flash('Prezzo o quantità non validi.', 'danger')
        return redirect(url_for('admin_prodotti'))

    ok = query_commit(
        'UPDATE prodotti SET nome_p=%s, descrizione_p=%s, link_immagine=%s, prezzo=%s, quantita_disponibile=%s, fk_categoria=%s WHERE id_prodotto=%s',
        (nome, descrizione, link_img, prezzo, qty, fk_cat, id_p)
    )
    if ok:
        flash('Prodotto modificato con successo.', 'success')
    else:
        flash('Errore durante la modifica del prodotto.', 'danger')
    return redirect(url_for('admin_prodotti'))


@app.route('/admin/prodotti/elimina', methods=['POST'])
@admin_required
def admin_elimina_prodotto():
    id_p = request.form.get('id_prodotto')
    ok   = query_commit('DELETE FROM prodotti WHERE id_prodotto=%s', (id_p,))
    if ok:
        flash('Prodotto eliminato.', 'success')
    else:
        flash('Impossibile eliminare il prodotto.', 'danger')
    return redirect(url_for('admin_prodotti'))

# ─────────────────────────────────────────────────
#  ROUTE — ADMIN: CATEGORIE
# ─────────────────────────────────────────────────
@app.route('/admin/categorie')
@admin_required
def admin_categorie():
    categorie = query_fetchall("""
        SELECT c.*, p.nome_c AS padre
        FROM categorie c
        LEFT JOIN categorie p ON c.fk_categoria_c = p.id_categoria
        ORDER BY c.nome_c
    """) or []
    return render_template('admin/categorie.html', categorie=categorie)


@app.route('/admin/categorie/aggiungi', methods=['POST'])
@admin_required
def admin_aggiungi_categoria():
    nome   = request.form.get('nome_c', '').strip()
    padre  = request.form.get('fk_categoria_c', '').strip() or None
    if not nome:
        flash('Nome categoria obbligatorio.', 'danger')
        return redirect(url_for('admin_categorie'))
    ok = query_commit(
        'INSERT INTO categorie (nome_c, fk_categoria_c) VALUES (%s,%s)', (nome, padre))
    flash('Categoria aggiunta.' if ok else 'Errore.', 'success' if ok else 'danger')
    return redirect(url_for('admin_categorie'))


@app.route('/admin/categorie/modifica', methods=['POST'])
@admin_required
def admin_modifica_categoria():
    id_c  = request.form.get('id_categoria')
    nome  = request.form.get('nome_c', '').strip()
    padre = request.form.get('fk_categoria_c', '').strip() or None
    ok    = query_commit(
        'UPDATE categorie SET nome_c=%s, fk_categoria_c=%s WHERE id_categoria=%s',
        (nome, padre, id_c))
    flash('Categoria aggiornata.' if ok else 'Errore.', 'success' if ok else 'danger')
    return redirect(url_for('admin_categorie'))


@app.route('/admin/categorie/elimina', methods=['POST'])
@admin_required
def admin_elimina_categoria():
    id_c = request.form.get('id_categoria')
    ok   = query_commit('DELETE FROM categorie WHERE id_categoria=%s', (id_c,))
    flash('Categoria eliminata.' if ok else 'Impossibile eliminare (prodotti associati?).', 'success' if ok else 'danger')
    return redirect(url_for('admin_categorie'))

# ─────────────────────────────────────────────────
#  ROUTE — ADMIN: ORDINI
# ─────────────────────────────────────────────────
@app.route('/admin/ordini')
@admin_required
def admin_ordini():
    ordini = query_fetchall("""
        SELECT o.*, u.username_u, p.nome_p
        FROM ordini o
        JOIN utenti u ON o.fk_utente = u.id_utente
        JOIN prodotti p ON o.fk_prodotto = p.id_prodotto
        ORDER BY o.data_ordine DESC, o.id_ordine DESC
    """) or []
    return render_template('admin/ordini.html', ordini=ordini)


@app.route('/admin/ordini/aggiorna', methods=['POST'])
@admin_required
def admin_aggiorna_ordine():
    numero_ordine = request.form.get('numero_ordine', '').strip()
    stato         = request.form.get('stato_ordine', 'In attesa')
    pagato        = 1 if request.form.get('pagamento_ordine') else 0
    if not numero_ordine:
        flash('Numero ordine mancante.', 'danger')
        return redirect(url_for('admin_ordini'))
    ok = query_commit(
        'UPDATE ordini SET stato_ordine=%s, pagamento_ordine=%s WHERE numero_ordine=%s',
        (stato, pagato, numero_ordine)
    )
    flash('Ordine aggiornato.' if ok else 'Errore aggiornamento ordine.', 'success' if ok else 'danger')
    return redirect(url_for('admin_ordini'))

# ─────────────────────────────────────────────────
#  ROUTE — ADMIN: COUPON
# ─────────────────────────────────────────────────
@app.route('/admin/coupon')
@admin_required
def admin_coupon():
    coupon_list = lista_coupon()
    return render_template('admin/coupon.html', coupon_list=coupon_list)


@app.route('/admin/coupon/crea', methods=['POST'])
@admin_required
def admin_crea_coupon():
    codice   = request.form.get('codice', '').strip().upper()
    sconto   = request.form.get('sconto', '0')
    scadenza = request.form.get('scadenza', '')
    utilizzi = request.form.get('utilizzi', '100')

    if not codice or not scadenza:
        flash('Codice e data di scadenza obbligatori.', 'danger')
        return redirect(url_for('admin_coupon'))

    try:
        sconto   = int(sconto)
        utilizzi = int(utilizzi)
    except ValueError:
        flash('Valori non validi.', 'danger')
        return redirect(url_for('admin_coupon'))

    ok = crea_coupon(codice, sconto, scadenza, utilizzi)
    flash(f'Coupon {codice} creato.' if ok else 'Errore creazione coupon (Redis offline?).', 'success' if ok else 'danger')
    return redirect(url_for('admin_coupon'))


@app.route('/admin/coupon/elimina', methods=['POST'])
@admin_required
def admin_elimina_coupon():
    codice = request.form.get('codice', '').strip().upper()
    ok = elimina_coupon(codice)
    flash(f'Coupon {codice} eliminato.' if ok else 'Errore.', 'success' if ok else 'danger')
    return redirect(url_for('admin_coupon'))

# ─────────────────────────────────────────────────
#  ROUTE — ADMIN: CORRIERI
# ─────────────────────────────────────────────────
@app.route('/admin/corrieri')
@admin_required
def admin_corrieri():
    corrieri_raw = query_fetchall('SELECT * FROM corrieri ORDER BY compagnia') or []
    corrieri = []
    for c in corrieri_raw:
        c = dict(c)
        aree = c.get('aree_disponibili')
        if isinstance(aree, str):
            try:
                c['aree_disponibili'] = json.loads(aree)
            except (json.JSONDecodeError, TypeError):
                c['aree_disponibili'] = []
        elif aree is None:
            c['aree_disponibili'] = []
        corrieri.append(c)
    return render_template('admin/corrieri.html', corrieri=corrieri)


@app.route('/admin/corrieri/aggiungi', methods=['POST'])
@admin_required
def admin_aggiungi_corriere():
    compagnia  = request.form.get('compagnia', '').strip()
    numero     = request.form.get('numero_corriere', '').strip()
    aree_raw   = request.form.get('aree_disponibili', '').strip()
    costo_km   = request.form.get('costo_per_km', '0')
    costo_kg   = request.form.get('costo_al_kg', '0')

    if not compagnia or not numero:
        flash('Compagnia e numero corriere obbligatori.', 'danger')
        return redirect(url_for('admin_corrieri'))

    aree_json = json.dumps([a.strip() for a in aree_raw.split(',') if a.strip()]) if aree_raw else '[]'

    try:
        costo_km = float(costo_km)
        costo_kg = float(costo_kg)
    except ValueError:
        costo_km = costo_kg = 0.0

    ok = query_commit(
        'INSERT INTO corrieri (compagnia, numero_corriere, aree_disponibili, costo_per_km, costo_al_kg) VALUES (%s,%s,%s,%s,%s)',
        (compagnia, numero, aree_json, costo_km, costo_kg)
    )
    flash('Corriere aggiunto.' if ok else 'Errore.', 'success' if ok else 'danger')
    return redirect(url_for('admin_corrieri'))


@app.route('/admin/corrieri/modifica', methods=['POST'])
@admin_required
def admin_modifica_corriere():
    id_c      = request.form.get('id_corriere')
    compagnia = request.form.get('compagnia', '').strip()
    numero    = request.form.get('numero_corriere', '').strip()
    aree_raw  = request.form.get('aree_disponibili', '').strip()
    costo_km  = request.form.get('costo_per_km', '0')
    costo_kg  = request.form.get('costo_al_kg', '0')

    if not compagnia or not numero:
        flash('Compagnia e numero corriere obbligatori.', 'danger')
        return redirect(url_for('admin_corrieri'))

    aree_json = json.dumps([a.strip() for a in aree_raw.split(',') if a.strip()]) if aree_raw else '[]'
    try:
        costo_km = float(costo_km)
        costo_kg = float(costo_kg)
    except ValueError:
        costo_km = costo_kg = 0.0

    ok = query_commit(
        'UPDATE corrieri SET compagnia=%s, numero_corriere=%s, '
        'aree_disponibili=%s, costo_per_km=%s, costo_al_kg=%s '
        'WHERE id_corriere=%s',
        (compagnia, numero, aree_json, costo_km, costo_kg, id_c)
    )
    flash('Corriere aggiornato.' if ok else 'Errore durante la modifica.', 'success' if ok else 'danger')
    return redirect(url_for('admin_corrieri'))


@app.route('/admin/corrieri/elimina', methods=['POST'])
@admin_required
def admin_elimina_corriere():
    id_c = request.form.get('id_corriere')
    ok   = query_commit('DELETE FROM corrieri WHERE id_corriere=%s', (id_c,))
    flash('Corriere eliminato.' if ok else 'Impossibile eliminare.', 'success' if ok else 'danger')
    return redirect(url_for('admin_corrieri'))

# ─────────────────────────────────────────────────
#  ROUTE — ADMIN: UTENTI
# ─────────────────────────────────────────────────
@app.route('/admin/utenti')
@admin_required
def admin_utenti():
    """Mostra tutti gli utenti registrati."""
    utenti = query_fetchall("""
        SELECT u.*, mp.metodo, mp.tipo_carta
        FROM utenti u
        LEFT JOIN metodi_pagamenti mp ON u.fk_metodo_pagamento = mp.id_metodo_pagamento
        ORDER BY u.id_utente ASC
    """) or []
    return render_template('admin/utenti.html', utenti=utenti)


@app.route('/admin/utenti/toggle-admin', methods=['POST'])
@admin_required
def admin_toggle_admin():
    """Promuove o retrocede un utente ad admin. Non può agire su se stesso."""
    id_target = request.form.get('id_utente', '').strip()

    if not id_target:
        flash('Utente non valido.', 'danger')
        return redirect(url_for('admin_utenti'))

    # Impedisce di togliere i propri permessi admin per sbaglio
    if str(id_target) == str(session.get('utente')):
        flash('Non puoi modificare il tuo stesso account da qui.', 'warning')
        return redirect(url_for('admin_utenti'))

    # Legge il tipo_u attuale e lo inverte
    target = query_fetchone('SELECT tipo_u, username_u FROM utenti WHERE id_utente=%s', (id_target,))
    if not target:
        flash('Utente non trovato.', 'danger')
        return redirect(url_for('admin_utenti'))

    nuovo_tipo = 0 if target['tipo_u'] else 1
    ok = query_commit('UPDATE utenti SET tipo_u=%s WHERE id_utente=%s', (nuovo_tipo, id_target))

    if ok:
        azione = 'promosso ad Admin' if nuovo_tipo == 1 else 'retrocesso a Utente'
        flash(f'{target["username_u"]} è stato {azione}.', 'success')
    else:
        flash('Errore durante la modifica del ruolo.', 'danger')

    return redirect(url_for('admin_utenti'))


@app.route('/admin/utenti/elimina', methods=['POST'])
@admin_required
def admin_elimina_utente():
    """Elimina un utente. Non può eliminare se stesso."""
    id_target = request.form.get('id_utente', '').strip()

    if str(id_target) == str(session.get('utente')):
        flash('Non puoi eliminare il tuo stesso account.', 'warning')
        return redirect(url_for('admin_utenti'))

    ok = query_commit('DELETE FROM utenti WHERE id_utente=%s', (id_target,))
    flash('Utente eliminato.' if ok else 'Impossibile eliminare l\'utente.', 'success' if ok else 'danger')
    return redirect(url_for('admin_utenti'))


# ─────────────────────────────────────────────────
#  ROUTE — ADMIN: METODI PAGAMENTO
# ─────────────────────────────────────────────────
@app.route('/admin/metodi-pagamento')
@admin_required
def admin_metodi_pagamento():
    metodi = query_fetchall('SELECT * FROM metodi_pagamenti ORDER BY metodo, tipo_carta') or []
    return render_template('admin/metodi_pagamento.html', metodi=metodi)


@app.route('/admin/metodi-pagamento/aggiungi', methods=['POST'])
@admin_required
def admin_aggiungi_metodo():
    metodo     = request.form.get('metodo', '').strip()
    tipo_carta = request.form.get('tipo_carta', '').strip() or None
    if not metodo:
        flash('Nome metodo obbligatorio.', 'danger')
        return redirect(url_for('admin_metodi_pagamento'))
    ok = query_commit('INSERT INTO metodi_pagamenti (metodo, tipo_carta) VALUES (%s, %s)', (metodo, tipo_carta))
    flash('Metodo aggiunto.' if ok else 'Errore.', 'success' if ok else 'danger')
    return redirect(url_for('admin_metodi_pagamento'))


@app.route('/admin/metodi-pagamento/modifica', methods=['POST'])
@admin_required
def admin_modifica_metodo():
    id_m       = request.form.get('id_metodo_pagamento')
    metodo     = request.form.get('metodo', '').strip()
    tipo_carta = request.form.get('tipo_carta', '').strip() or None
    if not metodo:
        flash('Nome metodo obbligatorio.', 'danger')
        return redirect(url_for('admin_metodi_pagamento'))
    ok = query_commit('UPDATE metodi_pagamenti SET metodo=%s, tipo_carta=%s WHERE id_metodo_pagamento=%s', (metodo, tipo_carta, id_m))
    flash('Metodo aggiornato.' if ok else 'Errore.', 'success' if ok else 'danger')
    return redirect(url_for('admin_metodi_pagamento'))


@app.route('/admin/metodi-pagamento/elimina', methods=['POST'])
@admin_required
def admin_elimina_metodo():
    id_m = request.form.get('id_metodo_pagamento')
    ok   = query_commit('DELETE FROM metodi_pagamenti WHERE id_metodo_pagamento=%s', (id_m,))
    flash('Metodo eliminato.' if ok else 'Impossibile eliminare (utenti collegati?).', 'success' if ok else 'danger')
    return redirect(url_for('admin_metodi_pagamento'))


# ─────────────────────────────────────────────────
#  ROUTE — ADMIN: SPEDIZIONI
# ─────────────────────────────────────────────────
@app.route('/admin/spedizioni')
@admin_required
def admin_spedizioni():
    spedizioni = query_fetchall("""
        SELECT sp.*, o.numero_ordine, o.stato_ordine, o.data_ordine,
               u.username_u, co.compagnia, co.numero_corriere
        FROM spedizioni sp
        JOIN ordini  o   ON sp.fk_ordine   = o.id_ordine
        JOIN utenti  u   ON o.fk_utente    = u.id_utente
        JOIN corrieri co ON sp.fk_corriere = co.id_corriere
        GROUP BY sp.fk_ordine, sp.fk_corriere
        ORDER BY o.data_ordine DESC
    """) or []
    ordini_senza = query_fetchall("""
        SELECT DISTINCT o.numero_ordine, o.data_ordine, u.username_u, o.stato_ordine
        FROM ordini o
        JOIN utenti u ON o.fk_utente = u.id_utente
        WHERE o.stato_ordine = 'Spedito'
          AND o.id_ordine NOT IN (SELECT fk_ordine FROM spedizioni)
        ORDER BY o.data_ordine DESC
    """) or []
    corrieri = query_fetchall('SELECT * FROM corrieri ORDER BY compagnia') or []
    return render_template('admin/spedizioni.html',
        spedizioni=spedizioni, ordini_senza_spedizione=ordini_senza, corrieri=corrieri)


@app.route('/admin/spedizioni/aggiungi', methods=['POST'])
@admin_required
def admin_aggiungi_spedizione():
    numero_ordine = request.form.get('numero_ordine', '').strip()
    fk_corriere   = request.form.get('fk_corriere', '').strip()
    tracking      = request.form.get('tracking_spedizione', '').strip() or None
    if not numero_ordine or not fk_corriere:
        flash('Ordine e corriere obbligatori.', 'danger')
        return redirect(url_for('admin_spedizioni'))
    data_consegna_raw = request.form.get('data_consegna', '').strip() or None
    if data_consegna_raw:
        try:
            data_c = datetime.datetime.strptime(data_consegna_raw, '%Y-%m-%d').date()
            if data_c < datetime.date.today():
                flash('La data di consegna non puo essere nel passato.', 'danger')
                return redirect(url_for('admin_spedizioni'))
            data_consegna = data_consegna_raw
        except ValueError:
            flash('Formato data non valido.', 'danger')
            return redirect(url_for('admin_spedizioni'))
    else:
        data_consegna = None
    cnx = get_db()
    if not cnx:
        flash('Database non disponibile.', 'danger')
        return redirect(url_for('admin_spedizioni'))
    try:
        with cnx.cursor(dictionary=True) as cur:
            cur.execute('SELECT id_ordine FROM ordini WHERE numero_ordine=%s', (numero_ordine,))
            righe = cur.fetchall()
        with cnx.cursor() as cur:
            for r in righe:
                cur.execute(
                    'INSERT IGNORE INTO spedizioni (fk_ordine, fk_corriere, data_consegna, tracking_spedizione) VALUES (%s,%s,%s,%s)',
                    (r['id_ordine'], fk_corriere, data_consegna, tracking)
                )
            cur.execute('UPDATE ordini SET stato_ordine=%s WHERE numero_ordine=%s', ('Spedito', numero_ordine))
        cnx.commit()
        flash(f'Spedizione registrata per ordine #{numero_ordine}.', 'success')
    except MySQLError:
        cnx.rollback()
        flash('Errore salvataggio spedizione.', 'danger')
    finally:
        cnx.close()
    return redirect(url_for('admin_spedizioni'))


@app.route('/admin/spedizioni/consegna', methods=['POST'])
@admin_required
def admin_conferma_consegna():
    numero_ordine = request.form.get('numero_ordine', '').strip()
    if not numero_ordine:
        flash('Numero ordine mancante.', 'danger')
        return redirect(url_for('admin_spedizioni'))
    cnx = get_db()
    if not cnx:
        flash('Database non disponibile.', 'danger')
        return redirect(url_for('admin_spedizioni'))
    try:
        with cnx.cursor() as cur:
            cur.execute("""
                UPDATE spedizioni sp JOIN ordini o ON sp.fk_ordine = o.id_ordine
                SET sp.data_consegna = CURDATE() WHERE o.numero_ordine = %s
            """, (numero_ordine,))
            cur.execute('UPDATE ordini SET stato_ordine=%s, pagamento_ordine=1 WHERE numero_ordine=%s',
                        ('Consegnato', numero_ordine))
        cnx.commit()
        flash(f'Ordine #{numero_ordine} segnato come Consegnato.', 'success')
    except MySQLError:
        cnx.rollback()
        flash('Errore conferma consegna.', 'danger')
    finally:
        cnx.close()
    return redirect(url_for('admin_spedizioni'))


# ─────────────────────────────────────────────────
#  AVVIO APP
# ─────────────────────────────────────────────────
def setup():
    """
    Funzione di setup (richiesta dal professore).
    Crea DB, tabelle, dati minimi, admin default, strutture Redis, cartelle.
    """
    print('===========================================')
    print('  ShopNova — Setup in corso...')
    print('===========================================')
    for cartella in ['flask_session', os.path.join('static', 'img')]:
        os.makedirs(cartella, exist_ok=True)
    migrazione_db()
    setup_redis()
    print('===========================================')
    print('  Setup completato. Avvio Flask...')
    print('===========================================')


if __name__ == '__main__':
    setup()

    # 3. Avvio Flask
    cert = os.getenv('SSL_CERT', '')
    key  = os.getenv('SSL_KEY', '')
    host = os.getenv('APP_HOST', '0.0.0.0')
    port = int(os.getenv('APP_PORT', 443))

    if cert and key and os.path.exists(cert) and os.path.exists(key):
        print(f'[INFO] HTTPS abilitato su https://{host}:{port}')
        app.run(ssl_context=(cert, key), host=host, port=port)
    else:
        port = 5000
        print(f'[WARN] Certificati SSL non trovati — avvio in HTTP su http://{host}:{port}')
        app.run(host=host, port=port, debug=(os.getenv('FLASK_DEBUG', '0') == '1'))